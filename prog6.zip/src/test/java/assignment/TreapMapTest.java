package assignment;

import org.junit.jupiter.api.Test;

import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

class TreapMapTest {

    @Test
    void testIterator() {
        TreapMap<Integer,Integer> test = new TreapMap();
        for(int i=0;i<10;i++)
            test.insert(i,0);

        Iterator<Integer> iter = test.iterator();
        test.remove(10);
        while(iter.hasNext())
            System.out.println(iter.next());

    }


/*
    @Test
    void testMeld() {
        TreapMap<Integer,Integer> test = new TreapMap();
        TreapMap<Integer,Integer> test1 = new TreapMap();
        test.meld(test1);
    }

 */

    @Test
    void testDelete() {
        TreapMap<Integer,Integer> test = new TreapMap();
        test.insert(1,100);
        test.insert(2,100);
        test.insert(3,14);
        test.insert(4,17);


        test.remove(4);
        assertTrue(test.lookup(4)==null);

        test.remove(3);
        assertTrue(test.lookup(3)==null);
        test.remove(2);
        assertTrue(test.lookup(2)==null);
        test.remove(1);
        assertTrue(test.lookup(1)==null);

        //System.out.println(test.lookup(4));

    }

    @Test
    void demoTestMethod() {
        TreapMap<Integer,Integer> test = new TreapMap();
        test.insert(null,100);
        test.insert(2,100);
        test.insert(3,14);
        test.insert(4,17);



        //System.out.println(test.lookup(4));
        assertTrue(test.lookup(1)==null);
    }

    @Test
    void lookup() {
        TreapMap<Integer,Integer> test = new TreapMap();
        test.insert(1,69);
        test.insert(2,100000);

        System.out.println(test.lookup(2));
        //assertTrue(true);
    }


    @Test
    void insertnull() {
        TreapMap<Integer,Integer> test = new TreapMap();
        test.insert(null,69);
        test.insert(2,100000);
        test.lookup(null);
        //System.out.println(test.lookup(null));
        //assertTrue(true);
    }

    @Test
    void joinTest() {
        TreapMap<Integer,Integer> test = new TreapMap();
        TreapMap<Integer,Integer> test1 = new TreapMap();
        test.join(test1);
        //System.out.println(test.lookup(null));
        //assertTrue(true);
    }

    @Test
    void testToString() {
        TreapMap<Integer,Integer> test = new TreapMap();
        for(int i=0;i<10;i++)
            test.insert(i,0);

        System.out.println(test);

    }

}